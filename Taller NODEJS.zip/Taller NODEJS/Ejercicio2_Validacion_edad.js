function validarEdad(edad) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {

      // Validar que sea número
      if (typeof edad !== "number") {
        return reject("La edad debe ser un número");
      }

      if (edad >= 18) {
        resolve("Acceso permitido");
      } else {
        reject("Acceso denegado. Eres menor de edad");
      }

    }, 1000); // Simula asincronía
  });
}

// Uso con .then() y .catch()

validarEdad(20)
  .then(mensaje => {
    console.log(mensaje);
  })
  .catch(error => {
    console.error("Error:", error);
  });


// Uso con async/await
  async function ejecutarValidacion() {
  try {
    const mensaje = await validarEdad(20);
    console.log(mensaje);
  } catch (error) {
    console.error("Error:", error);
  }
}

ejecutarValidacion();