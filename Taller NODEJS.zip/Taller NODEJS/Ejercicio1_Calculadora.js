function operar(a, b, tipo) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {

      // Validar que sean números y que el tipo de operación sea válido
      if (typeof a !== "number" || typeof b !== "number") {
        return reject("Ambos valores deben ser números");
      }

      let resultado;

      switch (tipo) {
        case "suma":
          resultado = a + b;
          break;

        case "resta":
          resultado = a - b;
          break;

        case "multiplicacion":
          resultado = a * b;
          break;

        case "division":
          if (b === 0) {
            return reject("No se puede dividir entre 0");
          }
          resultado = a / b;
          break;

        default:
          return reject("Tipo de operación no válido");
      }

      resolve(resultado);

    }, 1000); // Simula asincronía (1 segundo)
  });
}

// Uso con .then() y .catch()

operar(10, 5, "division")
  .then(resultado => {
    console.log("Resultado:", resultado);
  })
  .catch(error => {
    console.error("Error:", error);
  });


// Uso con asynct

async function ejecutarOperacion() {
  try {
    const resultado = await operar(10, 5, "division");
    console.log("Resultado:", resultado);
  } catch (error) {
    console.error("Error:", error);
  }
}

ejecutarOperacion();