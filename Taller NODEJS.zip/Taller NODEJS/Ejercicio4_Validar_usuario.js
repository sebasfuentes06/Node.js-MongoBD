function validarUsuario(usuario, contraseña) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {

      // Validar que sean strings
      if (typeof usuario !== "string" || typeof contraseña !== "string") {
        return reject("Usuario y contraseña deben ser texto");
      }

      if (usuario === "admin" && contraseña === "1234") {
        resolve("Acceso concedido");
      } else {
        reject("Usuario o contraseña incorrectos");
      }

    }, 1000); // Simula consulta a base de datos
  });
}

// Uso con Promesas
validarUsuario("admin", "1234")
  .then(mensaje => {
    console.log(mensaje);
  })
  .catch(error => {
    console.error("Error:", error);
  });

// Uso con async/await

async function ejecutarLogin() {
  try {
    const mensaje = await validarUsuario("admin", "1234");
    console.log(mensaje);
  } catch (error) {
    console.error("Error:", error);
  }
}

ejecutarLogin();