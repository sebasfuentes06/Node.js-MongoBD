function convertirMoneda(valor, tasa) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {

      // Validar que sean números
      if (typeof valor !== "number" || typeof tasa !== "number") {
        return reject("Valor y tasa deben ser números");
      }

      // Validar que sean positivos
      if (valor < 0 || tasa <= 0) {
        return reject("El valor y la tasa deben ser mayores que 0");
      }

      const convertido = valor * tasa;

      resolve(convertido);

    }, 1000); // Simula 1 segundo
  });
}

// Uso con Promesas
convertirMoneda(100, 4000)
  .then(resultado => {
    console.log("Valor convertido:", resultado);
  })
  .catch(error => {
    console.error("Error:", error);
  });


// Uso con async/await

async function ejecutarConversion() {
  try {
    const resultado = await convertirMoneda(100, 4000);
    console.log("Valor convertido:", resultado);
  } catch (error) {
    console.error("Error:", error);
  }
}

ejecutarConversion();