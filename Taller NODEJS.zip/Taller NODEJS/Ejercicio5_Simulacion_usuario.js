function validarUsuario(usuario, contraseña) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (usuario === "admin" && contraseña === "1234") {
        resolve("Usuario validado");
      } else {
        reject("Credenciales incorrectas");
      }
    }, 1000);
  });
}



validarUsuario("admin", "1234")
  .then(mensaje => {
    console.log(mensaje);
    return "Bienvenido"; // simulamos segundo paso
  })
  .then(bienvenida => {
    console.log(bienvenida);
  })
  .catch(error => {
    console.error("Error:", error);
  });



  validarUsuario("admin", "0000")
  .then(mensaje => {
    console.log(mensaje);
    return "Bienvenido";
  })
  .then(bienvenida => {
    console.log(bienvenida);
  })
  .catch(error => {
    console.error("Error:", error);
  });


  // Uso con async/await


  async function loginCompleto(usuario, contraseña) {
  try {
    const mensaje = await validarUsuario(usuario, contraseña);
    console.log(mensaje);

    console.log("Bienvenido");

  } catch (error) {
    console.error("Error:", error);
  }
}

loginCompleto("admin", "1234");