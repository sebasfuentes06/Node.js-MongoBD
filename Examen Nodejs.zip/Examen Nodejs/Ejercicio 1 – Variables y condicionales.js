// Ejercicio 1 – Variables y condicionales

const edad = 21

if (edad >= 60) {
    console.log("La persona es adulto mayor");
} else if (edad >= 18) {
    console.log("La persona es mayor de edad");
} else {
    console.log("La persona es menor de edad");
}

console.log();