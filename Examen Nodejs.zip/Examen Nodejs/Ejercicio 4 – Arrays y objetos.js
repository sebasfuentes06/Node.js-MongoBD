// Ejercicio 4 – Arrays y objetos

const productos = [{
    nombre: "Condones",
    precio: 5000,
    cantidad: 5
}, {
    nombre: "pantalones",
    precio: 50000,
    cantidad: 10
}, {
    nombre: "Camisetas",
    precio: 30000,
    cantidad: 15
}];

console.log(productos);

for (let i = 0; i < productos.length; i++) {

    const total = productos[i].precio * productos[i].cantidad;

    console.log("Producto:", productos[i].nombre);
    console.log("Total:", total);

}