// Ejercicio 5 – Crear una Promesa y consumir con: async / await y tambien con .then().

function consultarUsuario(){
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const usuario = {
                id: 1,
                nombre: "Sebastian Fuentes",
                activo: true
            };
            resolve(usuario);
        }, 2000);
    });

}

consultarUsuario().then(usuario => {
    console.log(usuario);
});

async function obtenerUsuario() {
    try {
        const usuario = await consultarUsuario();
        console.log(usuario);
    } catch (error) {
        console.error("Error al obtener el usuario:", error);
    }
}

obtenerUsuario();