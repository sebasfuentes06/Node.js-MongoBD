// Ejercicio 7 – Promesas con arrays y consumir con: async / await y tambien con .then().

function procesarProductos(productos) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const total = productos.reduce((acc, producto) => acc + (producto.precio * producto.cantidad), 0);
            resolve(`Total general: ${total}`);
        }, 2000);
    });
}

const pedidos = [
{producto:"Pan", precio:2000, cantidad:2},
{producto:"Queso", precio:5000, cantidad:1},
{producto:"Café", precio:3000, cantidad:4}
];

procesarProductos(pedidos)
.then(resultado => console.log(resultado))
.catch(error => console.error(error));

async function obtenerTotal(){
    try{
        const total = await procesarProductos(pedidos);
        console.log(total);
    }catch(error){
        console.error(error);
    }
}

obtenerTotal();