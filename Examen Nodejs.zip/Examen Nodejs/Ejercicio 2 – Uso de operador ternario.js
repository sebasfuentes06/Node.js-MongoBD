// Ejercicio 2 – Uso de operador ternario

const saldo = 50000;

const mensaje = saldo >= 50000 
? "Puedes realizar la compra" 
: "Saldo insuficiente";

console.log(mensaje);