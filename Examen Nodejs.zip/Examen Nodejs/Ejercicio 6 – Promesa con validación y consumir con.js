// Ejercicio 6 – Promesa con validación y consumir con: async / await y tambien con .then().

function procesarPedido(pedido) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (pedido.cantidad > 0) {
                const total = pedido.cantidad * pedido.precio;
                resolve(`El total del pedido es: ${total}`);
            } else {
                reject("La cantidad del pedido no puede ser menor o igual a cero");
            }
        }, 2000);
    });
}

procesarPedido({ cantidad: 3, precio: 10000 })
    .then(resultado => {
        console.log(resultado);
    })
    .catch(error => {
        console.error(error);
    });

async function obtenerPedido() {
    try {
        const pedido = await procesarPedido({ cantidad: 3, precio: 10000 });
        console.log(pedido);
    } catch (error) {
        console.error(error);
    }
}

obtenerPedido();
