// Ejercicio 3 – Estructura cíclica

const numero = [5, 4, 18, 21, 12];
for (let i = 0; i < numero.length; i++) {
    console.log(numero[i]*2);
}