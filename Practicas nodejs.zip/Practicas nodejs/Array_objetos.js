/*
Ejercicio: Calcular promedio de estudiantes aprobados

Tienes este arreglo de estudiantes:

const estudiantes = [
  { nombre: "Ana", nota: 4.5 },
  { nombre: "Luis", nota: 2.8 },
  { nombre: "Sofi", nota: 3.9 },
  { nombre: "Carlos", nota: 5.0 },
];
🎯 Objetivo

-Crear una función con Promesa que:
-Valide que el array no esté vacío.
-Filtre los estudiantes aprobados (nota >= 3.0).
-Calcule el promedio de los aprobados.
-Devuelva un objeto con:
-aprobados → array con los estudiantes aprobados
-promedio → promedio de notas
-cantidad → número de aprobados
-Si el array está vacío, debe hacer reject.
*/

const estudiantes = [
  { nombre: "Ana", nota: 4.5 },
  { nombre: "Luis", nota: 2.8 },
  { nombre: "Sofi", nota: 3.9 },
  { nombre: "Carlos", nota: 5.0 },
];

function procesarEstudiantes(lista) {
  return new Promise((resolve, reject) => {

    if (!Array.isArray(lista) || lista.length === 0) {
      return reject(new Error("La lista está vacía o no es válida"));
    }

    const aprobados = lista.filter(est => est.nota >= 3.0);  // Filtrar estudiantes aprobados

    const suma = aprobados.reduce((acc, est) => acc + est.nota, 0); // Sumar notas

    const promedio = aprobados.length > 0 ? suma / aprobados.length : 0; // Calcular promedio y se llama operador ternario

    resolve({
      aprobados,
      promedio,
      cantidad: aprobados.length
    });

  });
}