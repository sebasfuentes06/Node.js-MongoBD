/* 
Ejercicio: Procesar pedidos (array de objetos) con validaciones y cálculos

Tienes este arreglo de pedidos:

const pedidos = [
  { id: 1, cliente: "Ana", items: [{ sku: "A1", precio: 12000, cantidad: 2 }, { sku: "B1", precio: 8000, cantidad: 1 }], cupon: "DESC10" },
  { id: 2, cliente: "Luis", items: [{ sku: "A1", precio: 12000, cantidad: 1 }, { sku: "C1", precio: 20000, cantidad: 3 }], cupon: null },
  { id: 3, cliente: "Sofi", items: [{ sku: "D1", precio: 5000, cantidad: 0 }], cupon: "DESC20" }, // inválido (cantidad 0)
  { id: 4, cliente: "Juan", items: [], cupon: "DESC10" }, // inválido (sin items)
];

Y este objeto de cupones:

const cupones = {
  DESC10: 0.10,
  DESC20: 0.20,
};
Tu objetivo

Implementa 3 funciones que devuelvan Promesas y luego arma un pipeline con .then():

validarPedido(pedido)

Rechaza (reject) si:

items está vacío

algún item.cantidad <= 0

algún item.precio <= 0

Si pasa, resuelve (resolve) el pedido.

calcularSubtotal(pedido)

Resuelve el pedido con un nuevo campo:

subtotal = suma(precio * cantidad) de todos los items

aplicarDescuento(pedido, cupones)

Si el pedido tiene cupon y existe en cupones, calcula:

descuento = subtotal * porcentaje

Si no hay cupón válido, descuento = 0

Agrega:

total = subtotal - descuento

Resuelve el pedido final.

Reglas extra (para que tenga “múltiples operaciones”)

Al final debes obtener un reporte con:

pedidosOK: array de pedidos válidos procesados (con subtotal, descuento, total)

pedidosError: array con { id, cliente, error } de los pedidos inválidos

resumenClientes: objeto donde la llave es el cliente y el valor es el total gastado

ejemplo: { Ana: 28800, Luis: 72000 }

totalGeneral: suma de todos los totales válidos
*/

const pedidos = [
  { id: 1, cliente: "Ana", items: [{ sku: "A1", precio: 12000, cantidad: 2 }, { sku: "B1", precio: 8000, cantidad: 1 }], cupon: "DESC10" },
  { id: 2, cliente: "Luis", items: [{ sku: "A1", precio: 12000, cantidad: 1 }, { sku: "C1", precio: 20000, cantidad: 3 }], cupon: null },
  { id: 3, cliente: "Sofi", items: [{ sku: "D1", precio: 5000, cantidad: 0 }], cupon: "DESC20" },
  { id: 4, cliente: "Juan", items: [], cupon: "DESC10" },
];

const cupones = {
  DESC10: 0.10,
  DESC20: 0.20,
};

function validarPedido(pedido) {
  return new Promise((resolve, reject) => {
    if (!pedido.items || pedido.items.length === 0) {
      return reject("El pedido no tiene items");
    }

    for (let item of pedido.items) {
      if (item.cantidad <= 0) {
        return reject("Cantidad inválida");
      }
      if (item.precio <= 0) {
        return reject("Precio inválido");
      }
    }

    resolve(pedido);
  });
}

function calcularSubtotal(pedido) {
  return new Promise((resolve) => {
    const subtotal = pedido.items.reduce((acc, item) => {
      return acc + item.precio * item.cantidad;
    }, 0);

    pedido.subtotal = subtotal;

    resolve(pedido);
  });
}

function aplicarDescuento(pedido, cupones) {
  return new Promise((resolve) => {
    let descuento = 0;

    if (pedido.cupon && cupones[pedido.cupon]) {
      descuento = pedido.subtotal * cupones[pedido.cupon];
    }

    pedido.descuento = descuento;
    pedido.total = pedido.subtotal - descuento;

    resolve(pedido);
  });
}   

const pedidosOK = [];
const pedidosError = [];

const procesarPedidos = pedidos.map(pedido => {
  return validarPedido(pedido)
    .then(calcularSubtotal)
    .then(p => aplicarDescuento(p, cupones))
    .then(pedidoFinal => {
      pedidosOK.push(pedidoFinal);
    })
    .catch(error => {
      pedidosError.push({
        id: pedido.id,
        cliente: pedido.cliente,
        error: error
      });
    });
});

Promise.all(procesarPedidos).then(() => {

  const resumenClientes = {};

  pedidosOK.forEach(p => {
    if (!resumenClientes[p.cliente]) {
      resumenClientes[p.cliente] = 0;
    }
    resumenClientes[p.cliente] += p.total;
  });

  const totalGeneral = pedidosOK.reduce((acc, p) => acc + p.total, 0);

  console.log("Pedidos OK:", pedidosOK);
  console.log("Pedidos Error:", pedidosError);
  console.log("Resumen Clientes:", resumenClientes);
  console.log("Total General:", totalGeneral);

});

