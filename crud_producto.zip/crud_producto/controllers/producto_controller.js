const Producto = require('../models/producto');

// Crear producto
exports.crearProducto = async (req, res) => {
    try {
        console.log("BODY:", req.body);

        let producto = new Producto(req.body);
        await producto.save();
        res.send(producto);

    } catch (error) {
        console.log("ERROR REAL:", error);
        res.status(500).send(error.message);
    }
};

// Obtener todos
exports.obtenerProductos = async (req, res) => {
    try {
        const productos = await Producto.find();
        res.json(productos);
    } catch (error) {
        res.status(500).send('Error');
    }
};

// Obtener uno
exports.obtenerProducto = async (req, res) => {
    try {
        let producto = await Producto.findById(req.params.id);
        if (!producto) return res.status(404).json({ msg: 'No existe' });

        res.json(producto);
    } catch (error) {
        res.status(500).send('Error');
    }
};

// Actualizar
exports.actualizarProducto = async (req, res) => {
    try {
        let producto = await Producto.findById(req.params.id);
        if (!producto) return res.status(404).json({ msg: 'No existe' });

        producto = await Producto.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(producto);
    } catch (error) {
        res.status(500).send('Error');
    }
};

// Eliminar
exports.eliminarProducto = async (req, res) => {
    try {
        let producto = await Producto.findById(req.params.id);
        if (!producto) return res.status(404).json({ msg: 'No existe' });

        await Producto.findByIdAndDelete(req.params.id);
        res.json({ msg: 'Producto eliminado' });
    } catch (error) {
        res.status(500).send('Error');
    }
};