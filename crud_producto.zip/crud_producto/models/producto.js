const mongoose = require('mongoose');

const ProductoSchema = mongoose.Schema({
    categoria: {
        type: String,
        required: true
    },
    nombre: {
        type: String,
        required: true
    },
    precio: {
        type: Number,
        required: true
    },
    stock: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model('Productos', ProductoSchema);