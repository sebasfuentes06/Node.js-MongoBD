const express = require('express');
const conectarDB = require('./config/bd');
require('dotenv').config();

const app = express();

// Conectar DB
conectarDB();

// Middleware
app.use(express.json());

// Rutas
app.use('/api/productos', require('./routes/producto_routes.js'));

// Puerto
const PORT = 3000;
        
app.listen(PORT, () => {
    console.log(`Servidor corriendo en puerto ${PORT}`);
});